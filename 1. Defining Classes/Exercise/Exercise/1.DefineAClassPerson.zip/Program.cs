﻿public class Program
{
    public static void Main()
    {
        Person firstPerson = new Person();

        firstPerson.Name = "Pesho";
        firstPerson.Age = 20;

        Person secondPerson = new Person
        {
            Name = "Gosho",
            Age = 18
        };

        Person thirdPerson = new Person
        {
            Name = "Stamat",
            Age = 43
        };
    }
}