﻿using System;
using System.Collections.Generic;
using System.Text;

namespace 2.CreatingConstructors
{
    class Person
    {
    }
}
